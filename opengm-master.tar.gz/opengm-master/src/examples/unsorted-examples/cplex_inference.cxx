#include <opengm/graphicalmodel/graphicalmodel.hxx>

int main() {
   return 0;
}
