% add opengm interface to path
addpath('../../');

opengm('h')