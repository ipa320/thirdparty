template<class GM>
void export_movemaker();