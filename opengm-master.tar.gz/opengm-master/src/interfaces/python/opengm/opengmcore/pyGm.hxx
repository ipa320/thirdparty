template<class GM>
void export_gm();

