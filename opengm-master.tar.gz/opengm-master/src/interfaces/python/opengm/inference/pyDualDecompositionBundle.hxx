#ifdef WITH_CONICBUNDLE
    template<class GM,class ACC>
    void export_dual_decomposition_bundle();
#endif