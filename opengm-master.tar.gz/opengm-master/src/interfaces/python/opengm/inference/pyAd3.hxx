#ifdef WITH_AD3
template<class GM,class ACC>
void export_ad3();
#endif