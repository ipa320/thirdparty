#ifdef WITH_LIBDAI
template<class GM,class ACC>
void export_libdai_inference();
#endif
