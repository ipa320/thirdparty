#ifdef WITH_QPBO
template<class GM,class ACC>
void export_reduced_inference();
#endif