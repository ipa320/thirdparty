#ifdef WITH_TRWS
template<class GM,class ACC>
void export_trws();
#endif