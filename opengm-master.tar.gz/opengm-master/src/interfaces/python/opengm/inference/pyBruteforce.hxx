template<class GM,class ACC>
void export_bruteforce();