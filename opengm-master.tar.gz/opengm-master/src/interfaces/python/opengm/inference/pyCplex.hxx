#ifdef WITH_CPLEX
template<class GM,class ACC>
void export_cplex();
#endif