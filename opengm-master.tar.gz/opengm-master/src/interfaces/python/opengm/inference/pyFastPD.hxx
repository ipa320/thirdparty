#ifdef WITH_FASTPD
template<class GM,class ACC>
void export_fast_pd();
#endif 