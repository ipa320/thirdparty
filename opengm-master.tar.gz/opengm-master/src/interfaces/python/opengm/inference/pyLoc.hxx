#ifdef WITH_AD3
template<class GM,class ACC>
void export_loc();
#endif