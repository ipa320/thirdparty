template<class GM,class ACC>
void export_partition_move();