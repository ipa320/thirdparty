#ifdef WITH_MRF
template<class GM,class ACC>
void export_mrf();
#endif