#ifndef NOVIGRA
template<class GM,class ACC>
void export_intersection_based();
#endif   
