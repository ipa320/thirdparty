Infer/Optimize a Graphical Model
-------------------------------- 

Belief propagation (Bp)
+++++++++++++++++++++++

.. literalinclude:: ../../examples/inference_bp.py


ICM
+++++++++++++++++++

.. literalinclude:: ../../examples/inference_icm.py


GraphCut
+++++++++++++++++++

.. literalinclude:: ../../examples/inference_graphcut.py 