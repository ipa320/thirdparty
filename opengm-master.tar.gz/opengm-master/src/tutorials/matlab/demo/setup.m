opengm_root  = '~/GIT/opengm/';
opengm_build = '~GIT/opengm/build/';

addpath([opengm_build,'src/interfaces/matlab/opengm/mex-src/'])
addpath(genpath([opengm_root,'src/interfaces/matlab/opengm/m_files/']))
