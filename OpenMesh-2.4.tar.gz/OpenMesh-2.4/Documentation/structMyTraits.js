var structMyTraits =
[
    [ "VertexT", "structMyTraits_1_1VertexT.html", "structMyTraits_1_1VertexT" ],
    [ "Normal", "structMyTraits.html#a85f818c1f4db2d21070fa2a319a0bdae", null ],
    [ "Point", "structMyTraits.html#ae284e0bf977881329835f14fae5a7fa8", null ],
    [ "VertexAttributes", "structMyTraits.html#ad875685b7a8a589ddc9a2455aa5c9f40a3240d04f10c701518864bee168853a62", null ],
    [ "FaceAttributes", "structMyTraits.html#abd48259beac51f559d7b61956c89b234ad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "HalfedgeAttributes", "structMyTraits.html#ab76ebc88281ec720405e33f8c4251889a2701a3a324d9cfc7d69485730eb73c23", null ],
    [ "FaceAttributes", "structMyTraits.html#abd48259beac51f559d7b61956c89b234ad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "HalfedgeAttributes", "structMyTraits.html#ab76ebc88281ec720405e33f8c4251889a2701a3a324d9cfc7d69485730eb73c23", null ],
    [ "EdgeAttributes", "structMyTraits.html#af6e0682770069295e8847f57adbbaf92ad1b0d16e2b2ac31654bdd7c1d586a500", null ],
    [ "VertexAttributes", "structMyTraits.html#ad875685b7a8a589ddc9a2455aa5c9f40a3240d04f10c701518864bee168853a62", null ],
    [ "FaceAttributes", "structMyTraits.html#abd48259beac51f559d7b61956c89b234ad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "EdgeAttributes", "structMyTraits.html#af6e0682770069295e8847f57adbbaf92ad1b0d16e2b2ac31654bdd7c1d586a500", null ],
    [ "VertexAttributes", "structMyTraits.html#ad875685b7a8a589ddc9a2455aa5c9f40a3240d04f10c701518864bee168853a62", null ],
    [ "FaceAttributes", "structMyTraits.html#abd48259beac51f559d7b61956c89b234ad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "VertexAttributes", "structMyTraits.html#ad875685b7a8a589ddc9a2455aa5c9f40a3240d04f10c701518864bee168853a62", null ],
    [ "HalfedgeAttributes", "structMyTraits.html#ab76ebc88281ec720405e33f8c4251889a2701a3a324d9cfc7d69485730eb73c23", null ],
    [ "FaceAttributes", "structMyTraits.html#abd48259beac51f559d7b61956c89b234ad44da413bf3420d9c5fee92c014ef4b1", null ],
    [ "VertexAttributes", "structMyTraits.html#ad875685b7a8a589ddc9a2455aa5c9f40a3240d04f10c701518864bee168853a62", null ],
    [ "EdgeAttributes", "structMyTraits.html#af6e0682770069295e8847f57adbbaf92ad1b0d16e2b2ac31654bdd7c1d586a500", null ]
];