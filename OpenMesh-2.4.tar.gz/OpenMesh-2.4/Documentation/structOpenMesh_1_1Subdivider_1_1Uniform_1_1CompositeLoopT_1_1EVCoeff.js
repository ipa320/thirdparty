var structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff =
[
    [ "compute_weight", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff_1_1compute__weight.html", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff_1_1compute__weight" ],
    [ "EVCoeff", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff.html#afb7c41edac2135d901a7bb1eafafffeb", null ],
    [ "init", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff.html#a20e9c92a4b77e9033a45b2bd1432bb19", null ],
    [ "operator()", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff.html#aa38aef45738f8599d1afb8e89e5e4edb", null ],
    [ "weights_", "structOpenMesh_1_1Subdivider_1_1Uniform_1_1CompositeLoopT_1_1EVCoeff.html#ab019f704f4bea47348a71569c316ac29", null ]
];