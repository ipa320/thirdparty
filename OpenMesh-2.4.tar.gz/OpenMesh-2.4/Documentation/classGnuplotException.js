var classGnuplotException =
[
    [ "GnuplotException", "classGnuplotException.html#a81fc74a5c019556a4d0ba2a042a63448", null ]
];