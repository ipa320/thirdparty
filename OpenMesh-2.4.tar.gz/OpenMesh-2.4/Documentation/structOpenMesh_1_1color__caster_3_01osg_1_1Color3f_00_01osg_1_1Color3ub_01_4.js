var structOpenMesh_1_1color__caster_3_01osg_1_1Color3f_00_01osg_1_1Color3ub_01_4 =
[
    [ "return_type", "structOpenMesh_1_1color__caster_3_01osg_1_1Color3f_00_01osg_1_1Color3ub_01_4.html#a892e043e1e4a9e272c849b88ed50a194", null ],
    [ "cast", "structOpenMesh_1_1color__caster_3_01osg_1_1Color3f_00_01osg_1_1Color3ub_01_4.html#a4b314d2f5e744637b97a3f1ca53d9f78", null ]
];