var structOpenMesh_1_1EdgeHandle =
[
    [ "EdgeHandle", "structOpenMesh_1_1EdgeHandle.html#aab6b69a79864ae71507c5f53c42c634a", null ]
];