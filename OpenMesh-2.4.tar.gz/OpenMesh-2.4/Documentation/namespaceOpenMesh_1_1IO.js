var namespaceOpenMesh_1_1IO =
[
    [ "BaseExporter", "classOpenMesh_1_1IO_1_1BaseExporter.html", "classOpenMesh_1_1IO_1_1BaseExporter" ],
    [ "ExporterT", "classOpenMesh_1_1IO_1_1ExporterT.html", "classOpenMesh_1_1IO_1_1ExporterT" ],
    [ "BaseImporter", "classOpenMesh_1_1IO_1_1BaseImporter.html", "classOpenMesh_1_1IO_1_1BaseImporter" ],
    [ "ImporterT", "classOpenMesh_1_1IO_1_1ImporterT.html", "classOpenMesh_1_1IO_1_1ImporterT" ],
    [ "_IOManager_", "classOpenMesh_1_1IO_1_1__IOManager__.html", "classOpenMesh_1_1IO_1_1__IOManager__" ],
    [ "Options", "classOpenMesh_1_1IO_1_1Options.html", "classOpenMesh_1_1IO_1_1Options" ],
    [ "BaseReader", "classOpenMesh_1_1IO_1_1BaseReader.html", "classOpenMesh_1_1IO_1_1BaseReader" ],
    [ "_OBJReader_", "classOpenMesh_1_1IO_1_1__OBJReader__.html", "classOpenMesh_1_1IO_1_1__OBJReader__" ],
    [ "_OFFReader_", "classOpenMesh_1_1IO_1_1__OFFReader__.html", "classOpenMesh_1_1IO_1_1__OFFReader__" ],
    [ "_OMReader_", "classOpenMesh_1_1IO_1_1__OMReader__.html", "classOpenMesh_1_1IO_1_1__OMReader__" ],
    [ "_PLYReader_", "classOpenMesh_1_1IO_1_1__PLYReader__.html", "classOpenMesh_1_1IO_1_1__PLYReader__" ],
    [ "_STLReader_", "classOpenMesh_1_1IO_1_1__STLReader__.html", "classOpenMesh_1_1IO_1_1__STLReader__" ],
    [ "binary", "structOpenMesh_1_1IO_1_1binary.html", "structOpenMesh_1_1IO_1_1binary" ],
    [ "BaseWriter", "classOpenMesh_1_1IO_1_1BaseWriter.html", "classOpenMesh_1_1IO_1_1BaseWriter" ],
    [ "_OBJWriter_", "classOpenMesh_1_1IO_1_1__OBJWriter__.html", "classOpenMesh_1_1IO_1_1__OBJWriter__" ],
    [ "_OFFWriter_", "classOpenMesh_1_1IO_1_1__OFFWriter__.html", "classOpenMesh_1_1IO_1_1__OFFWriter__" ],
    [ "_OMWriter_", "classOpenMesh_1_1IO_1_1__OMWriter__.html", "classOpenMesh_1_1IO_1_1__OMWriter__" ],
    [ "_PLYWriter_", "classOpenMesh_1_1IO_1_1__PLYWriter__.html", "classOpenMesh_1_1IO_1_1__PLYWriter__" ],
    [ "_STLWriter_", "classOpenMesh_1_1IO_1_1__STLWriter__.html", "classOpenMesh_1_1IO_1_1__STLWriter__" ]
];