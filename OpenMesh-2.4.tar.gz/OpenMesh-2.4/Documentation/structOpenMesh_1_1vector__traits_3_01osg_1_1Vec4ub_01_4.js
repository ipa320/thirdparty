var structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4 =
[
    [ "typed_size", "structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4.html#a7a51252e4d625e69e201009e7bf4bbfd", null ],
    [ "value_type", "structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4.html#ae8eb29b50057b76e719a33566a3f28f6", null ],
    [ "vector_type", "structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4.html#a4635655f198c7320403b6e0ff0ed3795", null ],
    [ "size", "structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4.html#a735238c6861d38ea79a01371400a75ee", null ],
    [ "size_", "structOpenMesh_1_1vector__traits_3_01osg_1_1Vec4ub_01_4.html#adba5105906953c1645434a2a95be9394", null ]
];