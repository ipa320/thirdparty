Changes applied to IBFS-LIB to get it usable for openGM:

1. Added missing include and namespace qualifier to file "ibfs.cpp".